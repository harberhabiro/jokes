const { body } = require('express-validator');

//register rules
// const registerRules = () => {
//     return [
//         body("username").trim().isLength({min: 3, max: 20}).withMessage("Username must be between 3-20 chararcters long"),
//         body("email").trim().isEmail().normalizeEmail().withMessage("Not a valid email address"),
//         body("password").trim().isLength({max: 1000}).isStrongPassword().withMessage("Password must be at least 8 characters long, 1 lowercase letter, 1 uppercase letter, 1 number, and 1 symbol"),
//             ]
// };

const userValidationRules = () => {
  [
    // username must be an email
    body('username').isEmail(),
    // password must be at least 5 chars long
    body('password').isLength({ min: 5 }),
  ]

  next();
}

module.exports = {
    userValidationRules,
}