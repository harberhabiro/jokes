const router = require("express").Router();
const pool = require("../db");
const argon2 = require("argon2");
const userValidationRules = require("../middlewares/authRules");
const validateRules = require("../middlewares/validateRules");
const sendEmail = require("../utils/sendEmail");
// const confirmationUrl = require("../utils/confirmationUrl");
// const auth = require("../middleware/auth");
// const guest = require("../middleware/guest");
// const badWords = require("../middleware/badWords");
// const fetch = require("node-fetch");
require("dotenv").config();

//sign up aka register a user
router.post("/register", userValidationRules, validateRules, async (req, res) => {
    try {
        console.log("hello");
    } catch (err) {
        console.error(err.message);
        res.status(500).json({success: false});
    }
});

module.exports = router;