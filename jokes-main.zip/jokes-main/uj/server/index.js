const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const redis = require("./redis");
const session = require("express-session");
const RedisStore = require("connect-redis")(session);
require("dotenv").config();
const app = express();

//middlewares
app.use(express.json());
app.use(cors());
app.use(helmet());

app.use(session({
    store: new RedisStore({ client: redis }),
    name: process.env.APP_NAME,
    secret: process.env.APP_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 1000 * 60 * 60 * 24 * 2,
        secure: false,
        sameSite: true
    }
}));

//routes
app.use("/auth", require("./routes/auth"));
// app.use("/email", require("./routes/emails"));
// app.use("/change", require("./routes/changes"));
// app.use("/profile", require("./routes/profile"));
// app.use("/post", require("./routes/posts"));
// app.use("/comment", require("./routes/comments"));

//server
app.listen(process.env.APP_PORT, () => console.log(`Server is up on port ${process.env.APP_PORT}`));