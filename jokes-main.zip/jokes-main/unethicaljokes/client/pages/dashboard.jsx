const dashboard = () => {
    return (
        <>
        <h1>Hello</h1>
        </>
    )
};

export default dashboard;