const Redis = require("ioredis");

module.exports = redis = new Redis();